package com.example.peliculas.models

class Pelicula (list: List<Pelicula_Item>)