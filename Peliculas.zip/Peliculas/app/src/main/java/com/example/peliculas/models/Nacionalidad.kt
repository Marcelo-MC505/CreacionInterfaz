package com.example.peliculas.models

class Nacionalidad (list: List<Nacionalidad_Item>)