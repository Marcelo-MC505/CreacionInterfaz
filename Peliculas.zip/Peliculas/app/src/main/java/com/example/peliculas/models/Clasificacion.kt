package com.example.peliculas.models

class Clasificacion (list: List<Clasificacion_Item>)