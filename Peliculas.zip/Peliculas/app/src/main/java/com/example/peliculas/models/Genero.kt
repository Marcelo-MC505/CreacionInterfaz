package com.example.peliculas.models

class Genero (list: List<Genero_Item>)