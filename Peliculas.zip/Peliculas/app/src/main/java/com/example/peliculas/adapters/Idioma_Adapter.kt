package com.example.peliculas.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.peliculas.databinding.ItemClasificacionBinding
import com.example.peliculas.databinding.ItemGeneroBinding
import com.example.peliculas.databinding.ItemIdiomaBinding
import com.example.peliculas.models.*

class Idioma_Adapter(val idioma_list: List<Idioma_Item>): RecyclerView.Adapter<Idioma_Adapter.IdiomaHolder>() {
    inner class IdiomaHolder(val binding: ItemIdiomaBinding): RecyclerView.ViewHolder(binding.root){
        fun bind(idioma: Idioma_Item){
            with(binding){
                TxtNombre.text = idioma.nombre
                TxtId.text = idioma.idIdioma.toString()
            }
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup, viewType: Int
    ): IdiomaHolder {
        val binding = ItemIdiomaBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return IdiomaHolder(binding)
    }

    override fun onBindViewHolder(holder: IdiomaHolder, position: Int) {
        holder.bind(idioma_list[position])
    }

    override fun getItemCount(): Int = idioma_list.size
}