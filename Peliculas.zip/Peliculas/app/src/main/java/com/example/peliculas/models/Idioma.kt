package com.example.peliculas.models

class Idioma (list: List<Idioma_Item>)