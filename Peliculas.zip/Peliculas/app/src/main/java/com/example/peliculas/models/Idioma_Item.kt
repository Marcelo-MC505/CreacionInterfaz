package com.example.peliculas.models

class Idioma_Item (
    val idIdioma: Int,
    val nombre: String,
    val activo: Boolean
)