package com.example.peliculas.adapters

import com.example.peliculas.databinding.ItemNacionalidadBinding
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.peliculas.models.*

class Nacionalidad_Adapter(val nacionalidad_list: List<Nacionalidad_Item>): RecyclerView.Adapter
<Nacionalidad_Adapter.NacionalidadHolder>() {
    inner class NacionalidadHolder(val binding: ItemNacionalidadBinding): RecyclerView.ViewHolder(binding.root){
        fun bind(nacionalidad: Nacionalidad_Item){
            with(binding){
                TxtNombre.text = nacionalidad.nombre
                TxtId.text = nacionalidad.idNacionalidad.toString()
            }
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup, viewType: Int
    ): NacionalidadHolder {
        val binding = ItemNacionalidadBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return NacionalidadHolder(binding)
    }

    override fun onBindViewHolder(holder: NacionalidadHolder, position: Int) {
        holder.bind(nacionalidad_list[position])
    }

    override fun getItemCount(): Int = nacionalidad_list.size
}