package com.example.peliculas.models

class Genero_Item (
    val idGenero: Int,
    val nombre: String,
    val activo: Boolean,
)