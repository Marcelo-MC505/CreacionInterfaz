package com.example.peliculas.models

class Nacionalidad_Item (
    val idNacionalidad: Int,
    val nombre: String,
    val activo: Boolean
)