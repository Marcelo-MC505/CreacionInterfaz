package com.example.peliculas.models

data class Clasificacion_Item (
    val idClasificacion: Int,
    val abreviacion: String,
    val nombre: String,
    val activo: Boolean
)